/*
 * AlarmWave.c
 *
 *  Created on: Nov 15, 2021
 *      Author: ASUS
 */


#include "MCUType.h"
#include "K65TWR_GPIO.h"
#include "AlarmWave.h"
//#include "SysTickDelay.h"

// 64 samples from sine wave with //
static const INT16U Lookup_Table[64] = {2047, 2248, 2447, 2642, 2831, 3012, 3185, 3346, 3495, 3630,3750, 3853, 3939, 4007, 4056, 4085,
										4095, 4085, 4056, 4007, 3939, 3853, 3750, 3630,3495, 3346, 3185, 3012, 2831, 2642, 2447, 2248,
										2047, 1846, 1647, 1452, 1263, 1082, 909, 748, 599, 464, 344, 241, 155, 87, 38, 9, 0,  9, 38,
										87, 155, 241, 344, 464, 599, 748, 909, 1082, 1263, 1452, 1647, 1846};


static INT8U index_counter;
void PIT0_IRQHandler(void);
//void AlarmWaveSetMode(INT8U Mode);
//void AlarmWaveInit(void);

/******************************************************************************
*AlarmWaveInit - this initialize the DAC and PIT counter

******************************************************************************/
void AlarmWaveInit(void){

	SIM->SCGC6 |= SIM_SCGC6_PIT(1);  //Turn on PIT clock
	SIM->SCGC2 |= SIM_SCGC2_DAC0(1); //TURN on the DAC clock

	PIT->MCR = PIT_MCR_MDIS(0);      //Enable PIT clock
	PIT->CHANNEL[0].LDVAL = 3119;
	PIT->CHANNEL[0].TCTRL = (PIT_TCTRL_TIE(1)|PIT_TCTRL_TEN(1));




	DAC0->C0 |= DAC_C0_DACRFS(1);		// volatge supply select
	DAC0->C1 |= DAC_C1_DACBFEN(0); 		//buffer
	DAC0->C0 |= DAC_C0_DACTRGSEL(1);	//software trigger
	DAC0->C0 |= DAC_C0_DACEN(1);		//dac enable



}




/******************************************************************************
*AlarmWaveControlTask - set up the look up table to the index counter

******************************************************************************/
void AlarmWaveSetMode(INT8U Mode){
	index_counter = 0;

	if (Mode == 1){

		NVIC_EnableIRQ(PIT0_IRQn);

	}

	else{
		NVIC_DisableIRQ(PIT0_IRQn);
		PIT->CHANNEL[0].TFLG = PIT_TFLG_TIF(1);
        DAC0->DAT[0].DATL = (INT8U)(Lookup_Table[index_counter]);
        DAC0->DAT[0].DATH = (INT8U)(Lookup_Table[index_counter]>>8);
	}


}




void PIT0_IRQHandler(void){



    DB3_TURN_ON();

    																	//write samples to the DAC for a second
    	PIT->CHANNEL[0].TFLG = PIT_TFLG_TIF(1);
        DAC0->DAT[0].DATL = (INT8U)(Lookup_Table[index_counter]);
        DAC0->DAT[0].DATH = (INT8U)(Lookup_Table[index_counter]>>8);

        if (index_counter == 63){
        	index_counter = 0;
        }
        else{
        	index_counter++;

        }

    DB3_TURN_OFF();

    }


